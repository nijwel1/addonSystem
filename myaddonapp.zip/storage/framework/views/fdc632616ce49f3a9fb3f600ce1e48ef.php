<h1>Hello this is test page from main route</h1>
<?php /**PATH D:\laragon\www\myaddonapp\resources\views/test.blade.php ENDPATH**/ ?>