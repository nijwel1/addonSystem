<!-- addons/Blog/Views/index.blade.php -->
<h1>Welcome to the Category Addon</h1>
<?php /**PATH D:\laragon\www\myaddonapp\addons\category/Views/category/index.blade.php ENDPATH**/ ?>