<!-- addons/Blog/Views/index.blade.php -->
<h1>Welcome to the Blog Addon</h1>
<?php /**PATH D:\laragon\www\myaddonapp\addons\Blog/Views/index.blade.php ENDPATH**/ ?>