<!-- resources/views/admin/addons/upload.blade.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Upload Addon</title>
</head>

<body>
    <h1>Upload Addon</h1>
    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <form action="<?php echo e(route('addons.upload.post')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="addon" required>
        <button type="submit">Upload Addon</button>
    </form>
</body>

</html>
<?php /**PATH D:\laragon\www\myaddonapp\resources\views/upload.blade.php ENDPATH**/ ?>