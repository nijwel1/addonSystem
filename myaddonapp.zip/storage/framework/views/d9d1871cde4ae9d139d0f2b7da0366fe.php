<h1>Welcome to the Blog create Addon page</h1>
<?php /**PATH D:\laragon\www\myaddonapp\addons\Blog/Views/blog/create.blade.php ENDPATH**/ ?>