<h1>Welcome to the Category create Addon page</h1>
<?php /**PATH D:\laragon\www\myaddonapp\addons\category/Views/category/create.blade.php ENDPATH**/ ?>