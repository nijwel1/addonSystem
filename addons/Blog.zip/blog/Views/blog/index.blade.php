<!-- addons/Blog/Views/index.blade.php -->
<h1>Welcome to the Blog Addon</h1>
